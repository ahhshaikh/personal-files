# Event Reference

# List of Events

| Event                | Payload Details                                                                                          |
| -------------------- | -------------------------------------------------------------------------------------------------------- |
| Gift Card Settlement | [Get Gift Card Settled Transactions Notification]($m/GetGiftcardSettledTransactionsNotificationResponse) |
