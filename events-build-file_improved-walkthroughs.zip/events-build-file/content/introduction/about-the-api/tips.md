# Tips and Best Practices

These are the tips.