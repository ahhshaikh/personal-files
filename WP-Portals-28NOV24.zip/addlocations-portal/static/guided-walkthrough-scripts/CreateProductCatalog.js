async function ProductCatalog(workflowCtx, portal) {
  return {
    Guide: {
      name: "API Workflow",
      stepCallback: async () => {
        return workflowCtx.showContent(`## Introduction
This is a API Workflow.`);
      },
    },
  };
}
