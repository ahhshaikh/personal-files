document.addEventListener("DOMContentLoaded", (event) => {
  APIMaticDevPortal.ready(async ({ registerWorkflow }) => {
    const { default: ProductCatalog } = await import(
      "./CreateProductCatalog.js"
    );
    const { default: ManageBillingPortal } = await import(
      "./ManageBillingPortal.js"
    );
    const { default: SubscriptionManagement } = await import(
      "./SubscriptionManagement.js"
    );
    // Register individual workflows
    registerWorkflow(
      "page:walkthroughs/awf-1/walkthrough-1",
      "Product Catalog Walkthrough",
      ProductCatalog
    );
    registerWorkflow(
      "page:walkthroughs/awf-2/walkthrough-1",
      "Billing Portal Management Walkthrough",
      ManageBillingPortal
    );
    registerWorkflow(
      "page:walkthroughs/awf-3/walkthrough-1",
      "Subscription Management Walkthrough",
      SubscriptionManagement
    );
  });
});
